package jp.kronos;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import jp.kronos.dto.Item;
import jp.kronos.dto.User;

public class DataSource {
	// ユーザ情報
	private static List<User> users = new ArrayList<>();
	
	// 商品情報
	private static List<Item> items = new ArrayList<>();

	// 初期化処理
	static {
		users.add(new User(1, "ohagi@example.com", "ohagi", "おはぎ", "京都府"));
		users.add(new User(2, "yomogi@example.com", "yomogi", "よもぎ", "鹿児島県"));
		users.add(new User(3, "warabi@example.com", "warabi", "わらび", "奈良県"));
		users.add(new User(4, "abekawa@example.com", "abekawa", "あべかわ", "静岡県"));
		users.add(new User(5, "kashiwa@example.com", "kashiwa", "かしわ", "東京都"));
		users.add(new User(6, "kankoro@example.com", "kankoro", "かんころ", "長崎県"));
		users.add(new User(7, "kuzu@example.com", "kuzu", "くず", "東京都"));
		users.add(new User(8, "mitarashi@example.com", "mitarashi", "みたらし", "岐阜県"));
		
		items.add(new Item(1, "ノートPC KroBook メモリ32GB SSD512GB", 200000, "A", 5, LocalDateTime.of(2022, 5, 10, 10, 18, 32)));
		items.add(new Item(2, "実践SQL", 1200, "D", 7, LocalDateTime.of(2022, 6, 5, 14, 23, 9)));
		items.add(new Item(3, "レンズ 一眼レフカメラ用 50mm F1.4", 45000, "A", 7, LocalDateTime.of(2022, 5, 15, 7, 3, 54)));
		items.add(new Item(4, "黒いタブレット SIMフリー 64GB", 32000, "B", 3, LocalDateTime.of(2022, 5, 19, 11, 32, 11)));
		items.add(new Item(5, "タブレット 9.7インチ シリコンケース", 3800, "S", 3, LocalDateTime.of(2022, 5, 19, 16, 51, 10)));
		items.add(new Item(6, "Javaプログラミング入門 第3版", 2800, "B", 4, LocalDateTime.of(2022, 6, 10, 14, 9, 49)));
		items.add(new Item(7, "黒い粉", 300, "S", 8, LocalDateTime.of(2022, 5, 25, 17, 12, 44)));
		items.add(new Item(8, "受講者Xの健診", 900, "A", 1, LocalDateTime.of(2022, 5, 30, 12, 45, 37)));
		items.add(new Item(9, "消せるボールペン", 300, "S", 8, LocalDateTime.of(2022, 6, 4, 9, 51, 56)));
		items.add(new Item(10, "ミラーレス一眼カメラ K02X", 98000, "A", 7, LocalDateTime.of(2022, 6, 8, 19, 20, 54)));
		items.add(new Item(11, "新！Javaのすべてがわかる本", 1500, "C", 4, LocalDateTime.of(2022, 6, 8, 22, 7, 8)));
		items.add(new Item(12, "プレミアム万年筆", 5000, "S", 3, LocalDateTime.of(2022, 6, 9, 15, 43, 11)));
		items.add(new Item(13, "なぜSQLが使われるのか 第12版", 4000, "S", 1, LocalDateTime.of(2022, 6, 10, 8, 12, 59)));
		items.add(new Item(14, "ノートパソコン SiroBook メモリ32GB SSD256GB", 128000, "B", 4, LocalDateTime.of(2022, 6, 15, 10, 50, 38)));
		items.add(new Item(15, "MySQL 8.0 マスター", 800, "E", 5, LocalDateTime.of(2022, 6, 15, 16, 20, 19)));
	}
	
	/**
	 * ユーザ情報取得
	 * @return ユーザ情報
	 */
	public static List<User> getUsers() {
		return users;
	}
	
	/**
	 * 商品情報取得
	 * @return 商品情報
	 */
	public static List<Item> getItems() {
		return items;
	}
}
