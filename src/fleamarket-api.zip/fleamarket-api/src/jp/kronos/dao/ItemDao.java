package jp.kronos.dao;

import java.util.List;

import jp.kronos.DataNotFoundException;
import jp.kronos.DataSource;
import jp.kronos.dto.Item;

public class ItemDao {
	/**
	 * 全件検索
	 * @return 商品情報（複数）
	 */
	public List<Item> findAll() {
		return DataSource.getItems();
	}
	
	/**
	 * 商品名による部分一致検索
	 * @param keyword 検索キーワード（商品名）
	 * @return 商品情報（複数）
	 */
	public List<Item> findByKeyword(String keyword) {
		/*
    	 * TODO
    	 * DataSourceクラスから商品情報（List）を取得し、商品名に引数のキーワードを含む情報を探す
    	 * ヒットした商品情報が格納されたListを返す
    	 */
		return null;
	}
	
	/**
	 * 一件検索
	 * @param id 検索ID
	 * @throws DataNotFoundException
	 */
    public void findById(int id) throws DataNotFoundException {
    	/*
    	 * TODO
    	 * 引数のIDをもとに商品情報を取得する
    	 * データが存在する場合：
    	 * 　何もしない
    	 * データが存在しない場合：
    	 * 　DataNotFoundExceptionをスローする
    	 * 　メッセージ「指定したIDの商品が見つかりません。」
    	 */
    	
    }
	
	/**
     * 商品登録
     * @param item 登録する商品情報
     */
    public void create(Item item) {
    	/*
    	 * TODO
    	 * DataSourceクラスから商品情報（List）を取得する
    	 * 引数の商品情報（インスタンス）に以下の内容をセットし、Listに追加する
		 * 　ID　　   : Listの要素数 + 1
		 * 　更新日時 : 現在日時
    	 */
        
    }
    
    /**
     * 商品更新
     * @param item 更新する商品情報
     */
    public void update(Item item) {
    	/*
    	 * TODO
    	 * DataSourceクラスから商品情報（List）を取得し、引数の商品情報のIDに一致する情報を探す
    	 * 該当する商品のインスタンスに更新情報をセットする
		 * 　商品名   : 引数の商品情報の商品名
		 * 　価格     : 引数の商品情報の価格
		 * 　状態     : 引数の商品情報の状態
		 * 　更新日時 : 現在日時
    	 */
    	
    }

    /**
     * 削除処理
     * @param id 削除する商品のID
     * @throws DataNotFoundException
     */
    public void remove(int id) throws DataNotFoundException {
    	/*
    	 * TODO
    	 * DataSourceクラスから商品情報（List）を取得し、引数のIDに一致する情報を探す
    	 * 一致する商品情報がある場合：
		 * 　Listから該当する商品情報を削除する
		 * 一致する商品情報がない場合：
		 * 　DataNotFoundExceptionをスローする
		 * 　メッセージ「指定したIDの商品が見つかりません。」
    	 */
    	
    }
    

}
