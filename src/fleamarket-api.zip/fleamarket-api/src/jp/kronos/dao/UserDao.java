package jp.kronos.dao;

import java.sql.SQLException;

import jp.kronos.DataNotFoundException;
import jp.kronos.dto.User;

public class UserDao {
	
	/**
	 * 一件検索
	 * @param email メールアドレス
	 * @param passwd パスワード
	 * @return ユーザ情報
	 * @throws SQLException
	 */
	public User findByEmailAndPassword(String email, String password) throws DataNotFoundException {
		/*
		 * TODO
		 * DataSourceクラスからユーザ情報（List）を取得し、引数のメールアドレスとパスワードに一致する情報を探す
		 * 一致するユーザ情報がある場合：
		 * 　一致したユーザ情報を返す
		 * 一致するユーザ情報がない場合：
		 * 　DataNotFoundExceptionをスローする
		 * 　メッセージ「メールアドレスまたはパスワードが正しくありません。」
		 */
		return null;
	}
}
