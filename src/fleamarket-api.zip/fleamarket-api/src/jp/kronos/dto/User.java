package jp.kronos.dto;

public class User {
	private Integer id; 		// ユーザID
	private String email; 		// メールアドレス
	private String password; 	// パスワード
	private String nickname; 	// ニックネーム
	private String region; 		// 発送元地域	※本演習では使用しない

	public User() {
		
	}
	
	public User(Integer id, String email, String password, String nickname, String region) {
		this.id = id;
		this.email = email;
		this.password = password;
		this.nickname = nickname;
		this.region = region;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}
}
