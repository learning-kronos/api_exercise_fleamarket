package jp.kronos.dto;

import java.time.LocalDateTime;

public class Item {
	private Integer id; 				// 商品ID
	private String name; 				// 商品名
	private Integer price; 				// 価格
	private String state; 				// 状態
	private Integer sellerId; 			// 出品者ユーザID
	private Integer buyerId; 			// 購入者ユーザID	※本演習では使用しない
	private LocalDateTime purchaseDt; 	// 購入日時			※本演習では使用しない
	private LocalDateTime updatedDt; 	// 更新日時

	public Item() {

	}

	public Item(Integer id, String name, Integer price, String state, Integer sellerId, LocalDateTime updatedDt) {
		this.id = id;
		this.name = name;
		this.price = price;
		this.state = state;
		this.sellerId = sellerId;
		this.updatedDt = updatedDt;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Integer getSellerId() {
		return sellerId;
	}

	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}

	public Integer getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(Integer buyerId) {
		this.buyerId = buyerId;
	}

	public LocalDateTime getPurchaseDt() {
		return purchaseDt;
	}

	public void setPurchaseDt(LocalDateTime purchaseDt) {
		this.purchaseDt = purchaseDt;
	}

	public LocalDateTime getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(LocalDateTime updatedDt) {
		this.updatedDt = updatedDt;
	}
}
